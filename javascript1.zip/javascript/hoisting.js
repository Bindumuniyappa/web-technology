//hoisting

//behaviour hoisting in var keyword

// console.log(a);
// var a;
// console.log(a);

// behaviour of hositing in let keyword

// console.log(b);//uncaught reference error
// let b;
// console.log(b);//ud


// behaviour of hositing in const keyword

console.log(c);//uncaught reference error
const c=1;
console.log(c);//1




