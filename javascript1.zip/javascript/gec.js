
// const b=200;
// var c=300;
// console.log(c);
// console.log(b);
// let a=100;
// console.log(a);

// const a=1;
// console.log(a);//1
// var b=20;
// console.log(b);//20
// var b=30;
// let h=40;
// console.log(b);//30
// console.log(h);//40

let s=100;
s=200;
console.log(s);
var c=300;
let a=400;
const d=500;
console.log(d);
console.log(a);
console.log(c);