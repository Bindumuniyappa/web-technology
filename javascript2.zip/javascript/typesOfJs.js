let b="Hello world";
console.log(b);