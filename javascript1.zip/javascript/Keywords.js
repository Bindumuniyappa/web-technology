// let h=100;
// var h=200;
// console.log(h);//SyntaxError: Identifier 'h' has already been declared

// var g=200;
// let g=300;
// console.log(g);//SyntaxError: Identifier 'g' has already been declared

// s=100;
// let s=200;
// console.log(s);//ReferenceError: Cannot access 's' before initialization

// const c=40;
// const c=50;
// console.log(c);//SyntaxError: Identifier 'c' has already been declared

//var keyword

// var a;
// console.log(a);//undefined
// a=2;
// console.log(a);//2
// var a;
// a=30;
// console.log(a);//30


//let keyword

// let a=100;
// console.log(a);//100.........................

// // let a=200;
// // console.log(a);//syntax error
// a=500;
// console.log(a);

// s=100;
// console.log(s);
// let s=200;
// console.log(s);//ReferenceError: Cannot access 's' before initialization

// s=100;
// console.log(s);
// var  s=200;
// console.log(s);